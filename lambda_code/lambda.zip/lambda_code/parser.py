import boto3
import json
import os

# Initialize Bedrock client (Claude/Mistral)
bedrock = boto3.client(service_name="bedrock-runtime")

def process_text(raw_text):
    """
    Takes raw OCR text from Textract and uses Bedrock to
    extract structured fields from the prior authorization form.
    
    Args:
        raw_text (str): text extracted from the scanned form
    
    Returns:
        dict: extracted fields in JSON
    """

    # Craft the LLM prompt
    prompt = f"""
    You are an expert medical data assistant.
    Analyze the following prior authorization form text:
    
    {raw_text}
    
    Identify and return in JSON format:
    {{
      "provider": "",
      "npi": "",
      "urgency": "",
      "missing_fields": [],
      "suggested_action": ""
    }}
    """

    print("🧠 Sending prompt to Bedrock...")

    try:
        response = bedrock.invoke_model(
            modelId="anthropic.claude-v2", # or mistral
            body=json.dumps({
                "prompt": prompt,
                "max_tokens": 300
            }),
            accept="application/json",
            contentType="application/json"
        )

        # decode Bedrock response
        model_output = json.loads(response["body"].read())
        print("🧠 Bedrock raw output:", model_output)

        # Typically you would parse it:
        parsed_json = json.loads(model_output.get("completion", "{}"))
        return parsed_json

    except Exception as e:
        print("❌ Bedrock parsing error:", e)
        return {
            "provider": None,
            "npi": None,
            "urgency": None,
            "missing_fields": [],
            "suggested_action": "Manual review required"
        }
