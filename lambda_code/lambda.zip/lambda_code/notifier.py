import boto3

# Initialize SNS client
sns = boto3.client('sns')

def send_notification(parsed_result):
    """
    Sends an SNS notification if required fields are missing
    in the prior authorization form.
    
    Args:
        parsed_result (dict): Output from Bedrock parser
    """
    missing_fields = parsed_result.get("missing_fields", [])

    if not missing_fields:
        print("No missing fields detected. No notification sent.")
        return

    message = (
        f"The submitted prior authorization form is missing the following fields: "
        f"{', '.join(missing_fields)}. Please review and resubmit."
    )

    try:
        response = sns.publish(
            TopicArn="arn:aws:sns:us-east-1:123456789012:healthcopilot-alerts",
            Message=message,
            Subject="Prior Authorization Incomplete"
        )
        print("Notification sent successfully. Message ID:", response['MessageId'])
    except Exception as e:
        print("Failed to send SNS notification:", e)
